<!DOCTYPE html>
<html>
    <head>
        <meta charset="utf-8">
        <title>Read</title>
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css" integrity="sha384-BVYiiSIFeK1dGmJRAkycuHAHRg32OmUcww7on3RYdg4Va+PmSTsz/K68vbdEjh4u" crossorigin="anonymous">
    </head>
    <body>
        <div class="container">
            <div class="page-header">
                <h1>Read Data</h1>
                <a href="index.php" class="btn btn-success">Return Home</a>
            </div>

            <?php 
                $id = isset($_GET['id']) ?$_GET['id'] :die("Record ID not found");

                include "config/database.php";

                try {
                    $query = "SELECT customer_name, contact_name, address, city, postal_code, country FROM customers WHERE id=? LIMIT 0,1";
                    
                    $stmt = $con->prepare($query);

                    $stmt->bindParam(1,$id);

                    $stmt->execute();

                    $row=$stmt->fetch(PDO::FETCH_ASSOC);

                    $CustName = $row["customer_name"];
                    $ContactName = $row["contact_name"];
                    $Phone = $row["phone"];
                    $Address = $row["address"];
                    $City = $row["city"];
                    $Postal_Code = $row["postal_code"];
                    $Country = $row["country"];

                } catch (PDOException $e) {
                    die("ERROR: ".$e->getMessage());
                }
            ?>

            <table class="table talbe-hover table-responsive table-bordered">
                <tr>
                    <td>Customer Name</td>
                    <td><?php echo $Customer_Name; ?></td>
                </tr>
                <tr>
                    <td>Contact Name</td>
                    <td><?php echo $Contact_Name; ?></td>
                 </tr>
                 <tr>
                    <td>Phone</td>
                    <td><?php echo $Contact_Name; ?></td>
                </tr>
                </tr>
                <tr>
                    <td>Address</td>
                    <td><?php echo $Address; ?></td>
                </tr>
                <tr>
                    <td>City</td>
                    <td><?php echo $City; ?></td>
                </tr>
                <tr>
                    <td>Postal Code</td>
                    <td><?php echo $Postal_Code; ?></td>
                </tr>
                <tr>
                    <td>Country</td>
                    <td><?php echo $Country; ?></td>
                </tr>
            </table>

        </div>
    </body>
</html>