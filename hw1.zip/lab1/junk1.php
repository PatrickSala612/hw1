<!DOCTYPE html>
<html>
    <head>
        <meta charset="utf-8">
        <title></title>
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css" integrity="sha384-BVYiiSIFeK1dGmJRAkycuHAHRg32OmUcww7on3RYdg4Va+PmSTsz/K68vbdEjh4u" crossorigin="anonymous">

        <style>
            .error {
                color: red;
            }
        </style>
    </head>
    <body>
        <div class="container">
            <div class="pageHeader">
                <h1>Add Customer Information</h1>
            </div>
            <?php 

                $CustName = "";
                $CustNameErr = "";
                $isCustNameValid = false;

                $ContactName = "";
                $ContactNameErr = "";
                $isContactNameValid = false;

                $Address = "";
                $AddressErr = "";
                $isAddressValid = false;

                $City = "";
                $CityErr = "";
                $isCityValid = false;

                $Zip = "";
                $ZipErr = "";
                $isZipValid = false;
                
                $Country = "";
                $CountryErr = "";
                $isCountryValid = false;

            if($_POST) {


                //Customer Name Validation
                if (empty($_POST['cuName'])) {

                    $CustNameErr = "Required Field";
                    $isCustNameValid = false;
                } else {
                    $CustName = sanitize_input($_POST['cuName']);
                    if (!preg_match("/^[a-zA-Z-' ]*$/", $CustName)) {
                        $CustNameErr = "Only letters and white space allowed";
                        $isCustNameValid = false;
                    } else {
                        $isCustNameValid = true;
                    }
                }

                //Contact name Validation
                if (empty($_POST['coName'])) {

                    $ContactNameErr = "Required Field";
                    $isContactNameValid = false;
                } else {
                    $ContactName = sanitize_input($_POST['coName']);
                    if (!preg_match("/^[a-zA-Z-' ]*$/", $ContactName)) {
                        $ContactNameErr = "Only letters and white space allowed";
                        $isContactNameValid = false;
                    } else {
                        $isContactNameValid = true;
                    }
                }

                //Address Validation
                if (empty($_POST['add'])) {

                    $AddressErr = "Required Field";
                    $isAddressValid = false;
                } else {
                    $Address = sanitize_input($_POST['add']);
                    if (!preg_match("/^[a-z0-9- ]+$/i", $Address)) {
                        $AddressErr = "Invalid Input";
                        $isAddressValid = false;
                    } else {
                        $isAddressValid = true;
                    }
                }

                //City Validation
                if (empty($_POST['ci'])) {

                    $CityErr = "Required Field";
                    $isCityValid = false;
                } else {
                    $City = sanitize_input($_POST['ci']);
                    if (!preg_match("/^[a-zA-Z-' ]*$/", $City)) {
                        $CityErr = "Only letters and white space allowed";
                        $isCityValid = false;
                    } else {
                        $isCityValid = true;
                    }
                }

                //Zip Validation
                if (empty($_POST['z'])) {

                    $ZipErr = "Required Field";
                    $isZipValid = false;
                } else {
                    $Zip = sanitize_input($_POST['z']);
                    if (!preg_match("/^[0-9]*$/", $Zip)) {
                        $ZipErr = "Only numbers allowed";
                        $isZipValid = false;
                    } else {
                        $isZipValid = true;
                    }
                }

                //Country Validation
                if (empty($_POST['cou'])) {

                    $CountryErr = "Required Field";
                    $isCountryValid = false;
                } else {
                    $Country = sanitize_input($_POST['cou']);
                    if (!preg_match("/^[a-zA-Z-' ]*$/", $Country)) {
                        $CountryErr = "Only letters and white space allowed";
                        $isCountryValid = false;
                    } else {
                        $isCountryValid = true;
                    }
                }
                

                if ($isCustNameValid && $isContactNameValid && $isAddressValid && $isCityValid && $isZipValid && $isCountryValid) {
                    
                    include "config/database.php";
                    
                    try {

                        $query = "INSERT INTO customers SET customerName =:cuName, contactName =:coName, address =:add, city =:ci, zip =:z, country =:cou";

                        $stmt = $con->prepare($query); 

                        $CustName = htmlspecialchars(strip_tags($_POST['cuName']));
                        $ContactName = htmlspecialchars(strip_tags($_POST['coName']));
                        $Address = htmlspecialchars(strip_tags($_POST['add']));
                        $City = htmlspecialchars(strip_tags($_POST['ci']));
                        $Zip = htmlspecialchars(strip_tags($_POST['z']));
                        $Country = htmlspecialchars(strip_tags($_POST['cou']));

                        $stmt->bindParam(':cuName', $CustName);
                        $stmt->bindParam(':coName', $ContactName);
                        $stmt->bindParam(':add', $Address);
                        $stmt->bindParam(':ci', $City);
                        $stmt->bindParam(':z', $Zip);
                        $stmt->bindParam(':cou', $Country);

                        if ($stmt -> execute()){
                            echo '<div class="alert alert-success" role="alert">Entry Successful</div>';
                            header("Location: index.php?action=added");
                        } else {
                            echo '<div class="alert alert-succeshs" role="alert">Entry failed. Please verify data is correct and resubmit.</div>';
                        }
                        } catch (PDOException $e) {
                            echo "error".$e->getMessage();
                        }
                    }
                }

            function sanitize_input ($data){

                $data = trim($data);
                $data = stripslashes($data);
                $data = htmlspecialchars($data);
                return $data;
      
              }
            
            ?>

            <form action="<?php echo htmlspecialchars($_SERVER['PHP_SELF']); ?>" method="post">
                <table class="table table-hover table-responsive table-bordered">

                    <tr>
                        <td>Customer Name: </td>
                        <td>
                            <input type="text" name="cuName" class="form-control">
                            <span class="error"><?php echo $CustNameErr; ?></span>
                        </td>
                    </tr>
                    <tr>
                        <td>Contact Name: </td>
                        <td>
                            <input type="text" name="coName" class="form-control">
                            <span class="error"><?php echo $ContactNameErr; ?></span>
                        </td>
                    </tr>
                    <tr>
                        <td>Address: </td>
                        <td>
                            <input type="text" name="add" class="form-control">
                            <span class="error"><?php echo $AddressErr; ?></span>
                        </td>
                    </tr>
                    <tr>
                        <td>City: </td>
                        <td>
                            <input type="text" name="ci" class="form-control">
                            <span class="error"><?php echo $CityErr; ?></span>
                        </td>
                    </tr>
                    <tr>
                        <td>Zip: </td>
                        <td>
                            <input type="text" name="z" class="form-control" >
                            <span class="error"><?php echo $ZipErr; ?></span>
                        </td>
                    </tr>
                    <tr>
                        <td>Country: </td>
                        <td>
                            <input type="text" name="cou" class="form-control">
                            <span class="error"><?php echo $CountryErr; ?></span>
                        </td>
                    </tr>
                    <tr>
                        <td></td>
                        <td>
                            <input type="submit" name="Submit" class="btn btn-primary" >
                            <a href="index.php" class="btn btn-danger">Cancel</a>
                        </td>
                    </tr>

                </table>
            </form>
        </div>
    </body>
</html>