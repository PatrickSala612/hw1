<!DOCTYPE html>
<html>
	<head>
		<meta charset="utf-8">
		<meta name="viewport" content="width=device-width, initial-scale=1">
		<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css" integrity="sha384-BVYiiSIFeK1dGmJRAkycuHAHRg32OmUcww7on3RYdg4Va+PmSTsz/K68vbdEjh4u" crossorigin="anonymous">
		<title>Customers Lab</title>
	</head>
		<body>
			<div class="container">
			<h2>Customers</h2>
				<div style='float: right;'>
					<a href="create.php" class="btn btn-primary">Create New</a>
				</div>
				<div>
					<?php 
            
                    $action = isset($_GET['action']) ? $_GET['action'] :"";

                    if ($action == "deleted"){
                        echo "<div class='alert alert-danger'>Record was deleted</div>";
                    } elseif ($action == "added") {
                        echo "<div class='alert alert-success'>Record was added</div>";
                    }

                ?>
				</div>
			</h2>
			
			<table class="table table-striped table-hover table-responsive">
				<head>
					<tr>						
						<th>Customer Name</th>
						<th>Contact Name</th>
						<th>Phone</th>
						<th>Address</th>
						<th>City</th>
						<th>Postal Code</th>
						<th>Country</th>
						<th>Action</th>
					</tr>
				</head>
				<tbody>
					<?php
						#include database connection
						include"config/database.php";

						#select all data
						$query = "SELECT Customer_Name, Contact_Name, Phone, Address, City, Postal_Code, Country From customers ORDER by id ASC";
						
						#preparing the statement
						$stmt = $con -> prepare($query);
						$stmt -> execute();
						$num = $stmt ->rowCount();

						while ($row = $stmt -> fetch(PDO :: FETCH_ASSOC))
						{
							extract($row);

							echo"<tr>";								
								echo"<td>{$Customer_Name}</td>";
								echo"<td>{$Contact_Name}</td>";
								echo"<td>{$Phone}</td>";
								echo"<td>{$Address}</td>";
								echo"<td>{$City}</td>";
								echo"<td>{$Postal_Code}</td>";
								echo"<td>{$Country}</td>";
								echo"<td>";
									echo "<a href='read.php?id={$id}'  class='btn btn-primary btn-sm'>Read</a>";
                            echo "      <a href='#'  class='btn btn-warning btn-sm'>Edit</a>";
                            echo "      <a href='#' onclick='delete_user({$id})' class='btn btn-danger btn-sm'>Delete</a>";
								echo"<td>";
							echo"</tr>";
						}
					?>
				</tbody>
			</table>
		</div>

		 <script>
            function delete_user(id){
                var answer = confirm("Are you sure you want to delete this user?");
                console.log(answer);
                if (answer) {
                window.location = "delete.php?id="+id;
                }
            }

        </script>
	</body>
</html>