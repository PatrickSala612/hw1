<!DOCTYPE html>
<html>
	<head>
		<meta charset="utf-8">
		<meta name="viewport" content="width=device-width, initial-scale=1">
		<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css" integrity="sha384-BVYiiSIFeK1dGmJRAkycuHAHRg32OmUcww7on3RYdg4Va+PmSTsz/K68vbdEjh4u" crossorigin="anonymous">
		<style type="text/css">
			.error {color:red;}
		</style>
		<title>PDO: Create a Record</title>
	</head>
	<body>
		<!-- Container Start -->
		<div class="container">
			<div class="pageHeader">
				<h1>Create New Customer Record</h1>
			</div>
			<?php

				#include database connection
				include"config/database.php";

				$Customer_Name = "";
				$customer_nameError = "";
				$isCustumer_NameValid = false;

				$Contact_Name = "";
				$contact_nameError = "";
				$isContact_NameValid = false;

				$Phone = "";
				$phoneError = "";
				$isPhoneValid = false;

				$Address = "";
				$addressError = "";
				$isAddValid = false;

				$City = "";
				$cityError = "";
				$isCityValid = false;

				$Postal_Code = "";
				$postal_codeError = "";
				$isPostal_CodeValid = false;

				$Country = "";
				$countryError = "";
				$isCountryValid = false;
				
			if($_POST)	
		
				
				
				{
					#Check if customer name is valid
					if (empty($_POST['customer_name']))
					{
						$customer_nameError = "Customer name is required";
						$isCustomer_NameValid = false;
					}
					else
					{
						$Customer_Name = sanitize_input($_POST['customer_name']);
						if (!preg_match("/^[a-zA-Z-' ]*$/",$Customer_Name))
						{
							$customer_nameError = "Only letters and whitespace allowed";
							$isCustomer_NameValid = false;
						}
						else
						{
							$isCustomer_NameValid = true;
						}
					}

					#Check if contact name is valid
					if (empty($_POST['contact_name']))
					{
						$contact_nameError = "Contact name is required";
						$isContact_NameValid = false;
					}
					else
					{
						$Contact_Name = sanitize_input($_POST['contact_name']);
						if (!preg_match("/^[a-zA-Z-' ]*$/", $Contact_Name))
						{
							$contact_nameError = "Only letters and whitespace allowed";
							$isContact_NameValid = false;
						}
						else
						{
							$isContact_NameValid = true;
						}
					}

					#Check if contact phone number is valid
					if (empty($_POST['phone']))
					{
						$phoneError = "Contact phone number is required";
						$isPhoneValid = false;
					}
					else
					{
						$Phone = sanitize_input($_POST['phone']);
						if (!preg_match("/^[+]?[1-9][0-9]{9,14}$/", $Phone))
						{
							$phoneError = "Please enter a valid phone number";
							$isPhoneValid = false;
						}
						else
						{
							$isPhoneValid = true;
						}
					}

					#Check if address is valid
					if (empty($_POST['address']))
					{
						$addressError = "Address is required";
						$isAddressValid = false;
					}
					else
					{
						$Add = sanitize_input($_POST['address']);
						if (!preg_match("/^[0-9a-zA-Z. ]+$/", $Add))
						{
							$addressError = "Please enter a valid address";
							$isAddressValid = false;
						}
						else
						{
							$isAddressValid = true;
						}
					}

					#Check if city is valid
					if (empty($_POST['city']))
					{
						$cityError = "City is required";
						$isCityValid = false;
					}
					else
					{
						$City = sanitize_input($_POST['city']);
						if (!preg_match("/^[a-zA-Z-' ]*$/", $City))
						{
							$cityError = "Only letters and whitespace allowed";
							$isCityValid = false;
						}
						else
						{
							$isCityValid = true;
						}
					}

					#Check if postal code is valid
					if (empty($_POST['postal_code']))
					{
						$postal_codeError = "Postal code is required";
						$isPostal_CodeValid = false;
					}
					else
					{
						$Postal_Code = sanitize_input($_POST['postal_code']);
						#This validation will only apply to United States postal codes.
						if (!preg_match("/^\d{5}(?:\-\d{4})?$/i", $Postal_Code))
						{
							$postal_codeError = "Please enter a valid postal code.";
							$isPostal_CodeValid = false;
						}
						else
						{
							$isPostal_CodeValid = true;
						}
					}

					#Check if country is valid
					if (empty($_POST['country']))
					{
						$countryError = "Country is required";
						$isCountryValid = false;
					}
					else
					{
						$Country = sanitize_input($_POST['country']);
						if (!preg_match("/^[a-zA-Z-' ]*$/", $Country))
						{
							$countryError = "Only letters and whitespace allowed";
							$isCountryValid = false;
						}
						else
						{
							$isCountryValid = true;
						}
					}

					if ($isCustomer_NameValid && $isContact_NameValid && $isPhoneValid && $isAddressValid && $isCityValid && $isPostal_CodeValid && $isCountryValid)

						include "config/database.php";
					{
						try
						{
							#Insert Query
							$query= "INSERT INTO customers SET Customer_Name=:customer_name, Contact_Name=:contact_name, Phone=:phone, Address=:address, City=:city, Postal_Code=:postal_code, Country=:country";

							#Prepare query for execution
							$stmt = $con -> prepare($query);

							$Customer_Name = htmlspecialchars(strip_tags($_POST['customer_name']));
							$Contact_Name = htmlspecialchars(strip_tags($_POST['contact_name']));
							$Phone = htmlspecialchars(strip_tags($_POST['phone']));
							$Address = htmlspecialchars(strip_tags($_POST['address']));
							$City = htmlspecialchars(strip_tags($_POST['city']));
							$Postal_Code = htmlspecialchars(strip_tags($_POST['postal_code']));
							$Country = htmlspecialchars(strip_tags($_POST['country']));

							#Bind parameters
							$stmt -> bindParam(':customer_name',$Customer_Name);
							$stmt -> bindParam(':contact_name',$Contact_Name);
							$stmt -> bindParam(':phone',$Phone);
							$stmt -> bindParam(':address',$Address);
							$stmt -> bindParam(':city',$City);
							$stmt -> bindParam(':postal_code',$Postal_Code);
							$stmt -> bindParam(':country',$Country);

							#Execute query

							if ($stmt -> execute())
							{
								Echo '<div class="alert alert-success" role="alert"> Entry Successful </div>';
							}
							else
							{
								echo '<div class="alert alert-warning" role="alert">Entry failed. Please verify data is correct and resubmit.</div>';
							}
						}
						catch(PDOException $e)
						{
							echo "Error".$e -> getMessage();
						}
					}
				}
				function sanitize_input ($data)
				{
					$data = trim($data);
					$data = stripslashes($data);
					$data = htmlspecialchars($data);
					return $data;
				}
			?>
			<form action="<?php echo htmlspecialchars($_SERVER['PHP_SELF']); ?>" method="post">
				<table class="table table-hover table-responsive table-bordered">
					<tr>
						<td>Customer Name</td>
						<td>
							<input type="text" name="customer_name" class="form-control" value="<?php echo $Customer_Name ;?>">
							<span class="Error"><?php echo $customer_nameError;?></span>
						</td>
					</tr>
					<tr>
						<td>Contact Name</td>
						<td>
							<input type="text" name="contact_name" class="form-control" value="<?php echo $Contact_Name ;?>">
							<span class="Error"><?php echo $contact_nameError;?></span>
						</td>
					</tr>
					<tr>
						<td>Contact Phone</td>
						<td>
							<input type="text" name="phone" class="form-control" value="<?php echo $Phone ;?>">
							<span class="Error"><?php echo $phoneError;?></span>
						</td>
					</tr>
					<tr>
						<td>Street Address</td>
						<td>
							<input type="text" name="address" class="form-control" value="<?php echo $Address ;?>">
							<span class="Error"><?php echo $addressError;?></span>
						</td>
					</tr>
					<tr>
						<td>City</td>
						<td>
							<input type="text" name="city" class="form-control" value="<?php echo $City ;?>">
							<span class="Error"><?php echo $cityError;?></span>
						</td>
					</tr>
					<tr>
						<td>Postal Code</td>
						<td>
							<input type="text" name="postal_code" class="form-control" value="<?php echo $Postal_Code ;?>">
							<span class="Error"><?php echo $postal_codeError;?></span>
						</td>
					</tr>
					<tr>
						<td>Country</td>
						<td>
							<input type="text" name="country" class="form-control" value="<?php echo $Country ;?>">
							<span class="Error"><?php echo $countryError;?></span>
						</td>
					</tr>
					<tr>
						<td></td>
						<td>
							<input type="submit" value="Submit" name="Submit" class="btn btn-success">		
							<a href="index.php" class="btn btn-primary">Home</a>
						</td>
					</tr>
				</table>
			</form>
		</div>
		<!-- Container End -->
	</body>
</html>